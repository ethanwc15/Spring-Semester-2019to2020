//Used Visual Studio Code - IDE
//Using the main function you already provided us
$(document).ready(function() 
{
    
    //Using an event for final data/form validation
    $("#reservation_form").submit(function(event) 
    {

        //We will be using this as a checker to see if all of the text boxes pass
        //the requirements from the user. If all are true, the form will be able
        //to be submitted.
        var isValid = true;
        
        //Listing variables in order for better ogranization
        var arrivalDate = document.forms["reservation_form"]["arrival_date"].value;
        var nights = document.forms["reservation_form"]["nights"].value;
        var name = document.forms["reservation_form"]["name"].value;
        var email = document.forms["reservation_form"]["email"].value;
        var phone = document.forms["reservation_form"]["phone"].value;
        var emailPattern = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}\b/;

        //I couldn't figure out $("text").firstChild.nodeValue from the slide examples for the following 
        //if statements, so I decided to go with .next().text(). By using .next().text(), I will have to 
        //use the original ids' from the HTML. Ex: #arrival_Date, #nights, etc..
        
        //Form validation for the arrival date text box
        if (arrivalDate == "") {
            $("#arrival_date").next().text("This field is required.");
            isValid = false;
        }
        else {
            $("#arrival_date").next().text("");
        }
        $("#arrival_date").val(arrivalDate);

        //Form validation for the nights text box
        if (nights == "") {
            $("#nights").next().text("This field is required.");
            isValid = false;
        }
        //Checking to see if the user input is a number by using (Not-a-Num)
        else if (isNaN(nights)) {
            $("#nights").next().text("This field must be numeric.");
            isValid = false;
        }
        else {
            $("#nights").next().text("");
        }
        $("#nights").val(nights); 

        //Form validation for the name text box
        if (name == "") {
            $("#name").next().text("This field is required.");
            isValid = false;
        }
        else {
            $("#name").next().text("");
        }
        $("#name").val(name);

        //Form validation for the email text box. Unfortunately, I couldn't figure out how to check the email pattern.
        if (email == "") {
            $("#email").next().text("This field is required.");
            isValid = false;
        } 
        else {
            $("#email").next().text("");
        }
        $("#email").val(email);

        //Form validation for the phone text box
        if (phone == "") {
            $("#phone").next().text("This field is required.");
            isValid = false;
        }
        else {
            $("#phone").next().text("");
        }
        $("#phone").val(phone);

        //If all of the form submissions aren't valid, we won't allow the form to be submitted. Even if one text box isn't
        //correct, we will prevent the form to be submitted. However, if all text boxes are correct, the form will be submitted.
        if (isValid == false) {
            event.preventDefault();   
        }
    });

    //Focusing the arrival date text box 
    window.onload = function() {
        $("arrival_date").focus();
    };

});