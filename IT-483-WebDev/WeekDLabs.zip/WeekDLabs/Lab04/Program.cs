﻿using System;

namespace Lab04
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 1, b = 3, c = 5;
            double x = 2.2, y = 4.4, z = 6.6, ans;
            ans = average(a, b);
            Console.Write("\naverage(a, b) = " + ans);
            ans = average(a, b, c);
            Console.Write("\naverage(a, b, c) = " + ans);
            ans = average(x, y);
            Console.Write("\naverage(x, y) = " + ans);
            ans = average(x, y, z);
            Console.Write("\naverage(x, y, z) = " + ans);
        }
        public static double average(int n1, int n2)
        {
            return (n1 + n2) / 2.0;
        }
        public static double average(int n1, int n2, int n3)
        {
            return (n1 + n2 + n3) / 3.0;
        }

        public static double average(double n1, double n2)
        {
            return (n1 + n2) / 2.0;
        }

        public static double average(double n1, double n2, double n3)
        {
            return (n1 + n2 + n3) / 3.0;
        }

    }
}
