﻿using System;

namespace Lab03
{
    class Program
    {
        static void Main(string[] args)
        {
            double curBal = 45.32;
            double amount;
            Console.WriteLine("Please enter a amount to update account by $");
            amount = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("\n");
            Console.WriteLine("Customer’s balance (before transaction) = $");
            Console.WriteLine(curBal + "\n");
            Console.WriteLine("Requested update amount = $");
            Console.WriteLine(amount + "\n");

            double actAmount;
            actAmount = transaction(curBal, amount);
            curBal += actAmount;

            Console.WriteLine("Actual update amount = $");
            Console.WriteLine(actAmount + "\n");
            Console.WriteLine("Customer’s balance (after transaction) = $");
            Console.WriteLine(curBal + "\n");
            Console.WriteLine("\nThank you and good-bye!\n");
        }


        public static double transaction(double bal, double amount)
        {
            double zero = 0;
            if (bal + amount < 0)
            {
                return zero;
            }
            else
            {
                return amount;
            }

        }

    }
}
