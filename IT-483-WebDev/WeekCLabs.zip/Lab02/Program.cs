﻿using System;

namespace Lab02
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome, please choose your eye-glass options!\n");

            double cost;

            Console.WriteLine("What kind of glasses would you like:\n1 -> prescription, 2 -> non-prescription :");
            int glassType = Convert.ToInt32(Console.ReadLine());

            if (glassType == 1)
            {
                cost = 40.00;
            }
            else
            {
                cost = 25.00;
            }

            Console.WriteLine("What kind of coating would you like:\n1 -> anti-glare, 2 -> brown tint :");
            int coatType = Convert.ToInt32(Console.ReadLine());

            if (coatType == 1)
            {
                cost = cost + 12.50;
            }
            else
            {
                cost = cost + 9.99;
            }

            Console.WriteLine("Your total cost is:" + cost);

        }
    }
}
