﻿using System;

namespace Lab01
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("CS 201 Restaurant Guide\n");

            String response;
            char s, f;
            Boolean spicy, fancy;

            Console.WriteLine("Do you like spicy food? (y / n): ");
            response = Console.ReadLine();
            s = response[0];

            if (s == 'y' || s == 'Y')
            {
                spicy = true;
            }
            else
            {
                spicy = false;
            }

            Console.WriteLine("Do you want to go to a fancy restaurant? (y / n): ");
            response = Console.ReadLine();
            f = response[0];

            if (f == 'y' || f == 'Y')
            {
                fancy = true;
            }
            else
            {
                fancy = false;
            }

            if (spicy && fancy)
            {
                Console.WriteLine("I suggest you to go to Thai Garden Palace.");
            }
            
            if (!spicy && !fancy)
            {
                Console.WriteLine("I suggest you to go to Joe's Diner.");
            }

            if (spicy && !fancy)
            {
                Console.WriteLine("I suggest you to go to Alberto's Tacqueria.");
            }

            if (!spicy && fancy)
            {
                Console.WriteLine("I suggest you to go to Chez Paris.");
            }

        }
    }
}
